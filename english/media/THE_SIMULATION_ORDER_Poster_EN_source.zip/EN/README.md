# THE SIMULATION ORDER — poster source (EN)

One source builds **all** images of this language edition: dark and white (print) A3 poster, dark and white A4 flyer, and the 2560×1440 wallpaper.

## Build

    pip install -r requirements.txt
    playwright install chromium
    python build.py

Images appear in `output/`:

| File | Size |
|---|---|
| THE_SIMULATION_ORDER_Poster_A3_EN_300dpi.png | 3508 × 4961 |
| THE_SIMULATION_ORDER_Poster_A4_EN_300dpi.png | 2480 × 3508 |
| THE_SIMULATION_ORDER_Poster_A3_EN_White_300dpi.png | 3508 × 4961 |
| THE_SIMULATION_ORDER_Poster_A4_EN_White_300dpi.png | 2480 × 3508 |
| THE_SIMULATION_ORDER_Wallpaper_EN_2560x1440.png | 2560 × 1440 |

## How it works

- `src/poster.html`, `src/a4.html`, `src/wall.html` are the dark sources. Edit the text there.
- The **white versions are generated automatically** from the dark sources by `build.py` (colour map, recoloured icons, emblem, city illustration and a black-on-white QR code). Nothing else needs editing.
- Font sizes fit the text automatically (script inside the HTML files).
- Fonts used: DejaVu Sans, DejaVu Sans Mono and (for the letter J) Liberation Sans. Install them for identical results.
- The QR code points to https://github.com/onethatseeks/the-simulation-order (change `URL` in `build.py` and regenerate `src/qr_github.png` for the dark version).
- `build/` and `output/` are created by the script and can be deleted at any time.
