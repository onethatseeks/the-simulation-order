#!/usr/bin/env python3
"""
THE SIMULATION ORDER - poster builder (EN edition)

Builds every poster image from the HTML sources in ./src :
  - dark A3 poster, dark A4 flyer
  - white (print-friendly) A3 poster, white A4 flyer   (generated automatically from the dark sources)
  - 16:9 wallpaper (2560 x 1440)

Usage:   python build.py
Output:  ./output/*.png   (300 dpi A3 = 3508x4961, A4 = 2480x3508)
Edit the text in src/poster.html, src/a4.html and src/wall.html - the white versions follow automatically.
"""
import re, shutil, sys
from pathlib import Path
import numpy as np
from PIL import Image

LANG = "EN"                      # FI or EN (used in the file names)
URL  = "https://github.com/onethatseeks/the-simulation-order"
ROOT = Path(__file__).resolve().parent
SRC, BUILD, OUT = ROOT / "src", ROOT / "build", ROOT / "output"

ICON_COLOR  = (184, 71, 15)    # white version: icons
GOLD_COLOR  = (168, 90, 0)     # white version: emblem
CITY_COLOR  = (150, 85, 20)    # white version: city illustration

ICONS = ([f"four{i}" for i in range(4)] + [f"yl{i}" for i in range(4)] + [f"yr{i}" for i in range(4)] +
         [f"al{i}" for i in range(5)] + [f"ar{i}" for i in range(4)] + [f"f{i}" for i in range(9)])

# dark -> white colour map (applied to the HTML/CSS)
COLORS = {"#0b0907": "#ffffff", "#100d09": "#ffffff", "#14100c": "#ffffff", "#17120d": "#ffffff",
          "#20160c": "#ffffff", "#2c2010": "#ffffff", "#3a2a14": "#ffffff", "#3a2c1b": "#d9c7a6",
          "#4a3722": "#c9a36a", "#a79a85": "#4a4a4a", "#b5a78f": "#4a4a4a", "#d4622a": "#b8470f",
          "#e6dccb": "#111111", "#f0a93a": "#a85a00"}

def recolor(src, dst, rgb, boost=1.0):
    a = np.asarray(Image.open(src).convert("RGBA")).astype(float)
    out = np.zeros(a.shape, np.uint8)
    out[..., 0], out[..., 1], out[..., 2] = rgb
    out[..., 3] = np.clip(a[..., 3] * boost, 0, 255).astype(np.uint8)
    Image.fromarray(out, "RGBA").save(dst)

def make_white_assets():
    for n in ICONS:
        recolor(BUILD / f"{n}.png", BUILD / f"{n}_p.png", ICON_COLOR, 1.15)
    recolor(BUILD / "emblem.png", BUILD / "emblem_p.png", GOLD_COLOR)
    a = np.asarray(Image.open(BUILD / "city_a.png").convert("RGBA")).astype(float)[..., 3] / 255
    a2 = np.clip((a - 0.22) * 2.4, 0, 1)                       # drop faint building fills, keep the lines
    out = np.zeros(a.shape + (4,), np.uint8)
    out[..., 0], out[..., 1], out[..., 2] = CITY_COLOR
    out[..., 3] = (a2 * 255).astype(np.uint8)
    Image.fromarray(out, "RGBA").save(BUILD / "city_p.png")
    try:                                                         # black-on-white QR code
        import cv2
        q = cv2.QRCodeEncoder.create().encode(URL)[2:-2, 2:-2]
        n, m, pad = q.shape[0], 14, 3
        px = np.full(((n + 2 * pad) * m,) * 2 + (3,), 255, np.uint8)
        for y in range(n):
            for x in range(n):
                if q[y, x] < 128:
                    px[(y + pad) * m:(y + pad + 1) * m, (x + pad) * m:(x + pad + 1) * m] = 0
        Image.fromarray(px).save(BUILD / "qr_p.png")
    except Exception as e:                                       # fall back to the shipped qr_p.png
        print("QR regeneration skipped (", e, ") - using src/qr_p.png")

def make_white_html(name):
    s = (BUILD / f"{name}.html").read_text(encoding="utf-8")
    s = s.replace("border:8px solid #f0a93a", "border:3px solid #c9862f").replace("rgba(58,42,20,0)", "rgba(255,255,255,0)")
    for a, b in COLORS.items():
        s = s.replace(a, b)
    keep = set(ICONS + ["emblem", "qr_github"])
    def sub(m):
        n = m.group(1)
        if n in keep: return 'src="%s.png"' % ("qr_p" if n == "qr_github" else n + "_p")
        if n in ("city", "city_a"): return 'src="city_p.png"'
        return m.group(0)
    s = re.sub(r'src="([A-Za-z0-9_]+)\.png"', sub, s)
    (BUILD / f"{name}_white.html").write_text(s, encoding="utf-8")

def main():
    if BUILD.exists(): shutil.rmtree(BUILD)
    shutil.copytree(SRC, BUILD); OUT.mkdir(exist_ok=True)
    make_white_assets(); make_white_html("poster"); make_white_html("a4")
    jobs = [  # html, viewport w, h, target size, output name
        ("poster",        1190, 1683, (3508, 4961), f"THE_SIMULATION_ORDER_Poster_A3_{LANG}_300dpi.png"),
        ("a4",            1190, 1683, (2480, 3508), f"THE_SIMULATION_ORDER_Poster_A4_{LANG}_300dpi.png"),
        ("poster_white",  1190, 1683, (3508, 4961), f"THE_SIMULATION_ORDER_Poster_A3_{LANG}_White_300dpi.png"),
        ("a4_white",      1190, 1683, (2480, 3508), f"THE_SIMULATION_ORDER_Poster_A4_{LANG}_White_300dpi.png"),
        ("wall",          1280,  720, (2560, 1440), f"THE_SIMULATION_ORDER_Wallpaper_{LANG}_2560x1440.png")]
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        b = p.chromium.launch()
        for name, w, h, size, out in jobs:
            pg = b.new_page(viewport={"width": w, "height": h}, device_scale_factor=size[0] / w)
            pg.goto((BUILD / f"{name}.html").as_uri()); pg.wait_for_timeout(800)
            tmp = BUILD / f"{name}_raw.png"; pg.screenshot(path=str(tmp)); pg.close()
            im = Image.open(tmp).convert("RGB")
            if im.size != size: im = im.resize(size, Image.LANCZOS)
            im.save(OUT / out); print("wrote", OUT / out)
        b.close()

if __name__ == "__main__":
    main()
