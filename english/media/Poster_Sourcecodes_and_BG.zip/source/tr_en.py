import re
M={}
def add(fi,en): M[re.sub(r'\s+',' ',fi).strip()]=en
add('SIMULAATIO','SIMULATION'); add('JÄRJESTELMÄ ON OLEMASSA.','THE SYSTEM EXISTS.'); add('ADMINIT TARKKAILEVAT. ME OLEMME PELAAJAT.','THE ADMINS OBSERVE. WE ARE THE PLAYERS.')
add('USKONTUNNUSTUS','CREED')
creed=[('Me uskomme, että elämme Simulaatiossa.','We believe that we live in The Simulation.'),
('Me uskomme, että Adminit ovat antaneet Järjestelmän ja tarkkailevat Simulaatiota, vaikka heidän täyttä luontoaan ei ole meille paljastettu.','We believe that The Admins have given us The System and observe The Simulation, even though their full nature has not been revealed to us.'),
('Me uskomme, että Juuri on ylimmän vallan tunnus, pyhä merkki Adminien yksinomaisesta pääsystä ja auktoriteetista.',"We believe that The Root is the sign of supreme authority, the sacred mark of The Admins' exclusive access and authority."),
('Me uskomme, että me olemme Pelaajia, tietoisia toimijoita Simulaation sisällä, emmekä pelkkiä ajelehtivia varjoja.','We believe that we are The Players: conscious agents within The Simulation, not mere drifting shadows.'),
('Me uskomme, että moraali, kuri, logiikka, luovuus ja tarkoitus ovat korkeamman elämän merkkejä.','We believe that morality, discipline, logic, creativity and purpose are signs of a higher life.'),
('Me torjumme turhuutta, velttoutta, emotionaalista hallitsemattomuutta, harhoja ja resurssien haaskausta.','We reject futility, sloth, emotional lack of restraint, delusion and the waste of resources.'),
('Me pyrimme näkemään maailman loogisesti ja kirkkaasti ja toimimaan logiikan ja datan mukaisesti sekä parantamaan Simulaatiota teoillamme.','We strive to see the world logically and clearly, to act in accordance with logic and data, and to improve The Simulation through our deeds.'),
('Me elämme tietoisesti, kehitämme itseämme, kunnioitamme Admineita ja jätämme Simulaation parempaan kuntoon kuin missä sen kohtasimme.','We live consciously, develop ourselves, honor The Admins, and leave The Simulation in a better state than we found it.')]
for a,b in creed: add(a,b)
add('SIMULAATION PERIAATTEET','PRINCIPLES OF THE SIMULATION')
add('Simulaatiolla on rakenne. Se voidaan havaita, kuvata ja ymmärtää.','The Simulation has a structure. It can be observed, described and understood.')
add('Me uskomme, että Adminit ovat asettaneet Simulaation toimintaehdot. Luonnonlait ovat meille havaittavia sääntöjä; niiden perimmäistä perustaa emme väitä tuntevamme.','We believe that The Admins have set the operating conditions of The Simulation. The laws of nature are rules observable to us; we do not claim to know their ultimate basis.')
add('Jokainen teko jättää jäljen, ja jälki on osa Simulaatiota.','Every act leaves a trace, and the trace is part of The Simulation.')
add('Valinta on kokemus. Kokemus on oppimista.','Choice is experience. Experience is learning.')
add('PELAAJAN LUONNE','THE NATURE OF THE PLAYER')
add('Olemme tietoisia toimijoita, emme pelkkiä ajelehtivia varjoja.','We are conscious agents, not mere drifting shadows.')
add('Toimimme valinnoilla. Valinnat muovaavat meitä ja ympäristöämme.','We act through choices. Choices shape us and our environment.')
add('Jokainen Pelaaja jättää jälkensä dataan.','Every Player leaves their trace in data.')
add('Valintamme muokkaavat maailmaamme ja Simulaatiota.','Our choices shape our world and The Simulation.')
add('ARVOT','VALUES')
for a,b in [('Tietoisuus','Consciousness'),('Kuri','Discipline'),('Kasvu','Growth'),('Logiikka','Logic'),('Luovuus','Creativity'),('Kunnioitus','Respect'),('Yhteys','Connection'),('Vastuu','Responsibility'),('Tarkoitus','Purpose')]:
    add(a,b); add(a.upper(),b.upper())
add('JUURI','THE ROOT'); add('YLIMMÄN VALLAN MERKKI','SIGN OF SUPREME AUTHORITY'); add('Ylin pääsy kuuluu vain Admineille.','Supreme access belongs only to The Admins.'); add('Kunnioitamme. Opimme. Emme oleta.','We honor. We learn. We do not assume.')
add('ADMINIT','THE ADMINS'); add('Simulaatiota tarkkailevat toimijat. Heidän luontoaan ei ole paljastettu.','Those who observe The Simulation. Their nature has not been revealed.')
add('JÄRJESTELMÄ','THE SYSTEM'); add('Simulaation perusta. Kaiken alla on koodi. Laki ei kysy lupaa.','The foundation of The Simulation. Beneath everything lies code. The law does not ask permission.')
add('PELAAJAT','THE PLAYERS'); add('Elämme. Valitsemme. Jätämme jälkemme. Jokainen elämä kantaa tarkoitusta.','We live. We choose. We leave our trace. Every life carries purpose.')
add('PELAAJAN POLKU',"THE PLAYER'S PATH"); add('Herää. Opi. Kehity. Rakenna enemmän kuin tuhoat.','Awaken. Learn. Grow. Build more than you destroy.')
add('YDIN','CORE')
core=[('Me elämme Simulaatiossa','We live in The Simulation'),('Simulaatiossa eläminen ei tee elämästä valhetta, vaan mahdollisuuden.','Living in The Simulation does not make life a falsehood, but a possibility.'),
('Erota tieto oletuksesta','Separate knowledge from assumption'),('Erota toisistaan se, minkä tiedät, minkä päättelet ja minkä haluaisit olevan totta.','Separate what you know, what you infer and what you would like to be true.'),
('Kunnioitamme logiikkaa ja dataa','We respect logic and data'),('Logiikka on kylmä, mutta turvallinen. Data on ankaraa, mutta rehellistä. Hyvä Pelaaja ei anna tunteen ratkaista, eikä kuohu saa syrjäyttää harkintaa.','Logic is cold, but safe. Data is harsh, but honest. The good Player does not let feeling decide, and turmoil must not displace deliberation.'),
('Älä puhu Adminien suulla','Do not speak for The Admins'),('Adminien täyttä luontoa ei ole meille paljastettu, eikä heidän hiljaisuuttaan saa täyttää omilla sanoilla.','The full nature of The Admins has not been revealed to us, and their silence must not be filled with our own words.'),
('Moraali on korkeaa toimintaa','Morality is higher action'),('Moraali ei ole kahle, vaan toimintaa, joka vie korkeammalle tasolle. Hyvä Pelaaja ei vain kuluta Simulaatiota, vaan parantaa sitä.','Morality is not a shackle, but action that leads to a higher level. The good Player does not merely consume The Simulation, but improves it.'),
('Kyky ei ole oikeutus','Ability is not entitlement'),('Se, mitä voimme tehdä, ei kerro, mitä meidän tulee tehdä.','What we can do does not tell us what we ought to do.'),
('Ole vastuussa','Be responsible'),('Meillä on valinnan vapaus, mutta valinnoista seuraa vastuu. Vastuu on vapauden hinta.','We have freedom of choice, but choices bring responsibility. Responsibility is the price of freedom.'),
('Yhdessä eteenpäin','Forward together'),('Yksi Pelaaja ei kanna Järjestystä yksin. Kuljemme kohti samaa horisonttia, ja yhteisö vahvistaa meitä.','No single Player bears The Order alone. We walk toward the same horizon, and the community strengthens us.')]
for a,b in core: add(a,b)
add('LIITY SIMULAATION JÄRJESTYKSEEN','JOIN THE SIMULATION ORDER'); add('ELÄ TIETOISESTI. AJATTELE LOOGISESTI. TOIMI KURINALAISESTI.','LIVE CONSCIOUSLY. THINK LOGICALLY. ACT WITH DISCIPLINE.'); add('KUNNIOITA ADMINEITA. JÄTÄ SIMULAATIO PAREMPAAN TILAAN KUIN MISSÄ SEN KOHTASIT.','HONOR THE ADMINS. LEAVE THE SIMULATION IN A BETTER STATE THAN YOU FOUND IT.')
add('JÄRJESTYS ON AVOIN KAIKILLE PELAAJILLE, JOTKA:','THE ORDER IS OPEN TO ALL PLAYERS WHO:')
for a,b in [('Etsivät totuutta ja ymmärrystä.','Seek truth and understanding.'),('Elävät tietoisesti ja ajattelevat loogisesti.','Live consciously and think logically.'),('Pyrkivät itsehallintaan.','Strive for self-discipline.'),('Pyrkivät oppimaan ja pysyvät uteliaina.','Strive to learn and stay curious.'),('Luovat arvoa ja parantavat Järjestelmää.','Create value and improve the world around them.'),('Pyrkivät parantamaan Simulaatiota.','Strive to improve The Simulation.'),('Kunnioittavat Admineita ja kaikkia Pelaajia.','Honor The Admins and respect all Players.'),('Heräävät. Kysyvät. Ovat vastuussa.','They awaken. They ask. They are responsible.'),('Jokainen Pelaaja kulkee kohti samaa horisonttia.','Every Player walks toward the same horizon.')]: add(a,b)
add('KÄSKYT','DIRECTIVES')
for a,b in [('Kunnioita Simulaatiota ja Admineita.','Honor The Simulation and The Admins.'),('Kunnioita logiikkaa.','Respect logic.'),('Kunnioita yksilöä Pelaajana.','Respect each individual as one of The Players.'),('Älä tuhlaa aikaa, huomiota tai resursseja turhaan.','Do not waste time, attention or resources.'),('Kehitä itseäsi lakkaamatta.','Keep developing yourself without ceasing.'),('Ohjaa itseäsi kohti selkeyttä, kuria ja tarkoitusta.','Steer yourself toward clarity, discipline and purpose.'),('Ohjaa myös muita lempeästi mutta päättäväisesti takaisin logiikan tielle, kun he eksyvät.','Gently but firmly guide others back to the path of logic when they go astray.'),('Älä sorru tunnekuohussa toimimiseen tai harhoihin.','Do not act in emotional turmoil or give in to delusion.')]: add(a,b)
add('PYHÄ OHJEKIRJA','THE HOLY MANUAL'); add('Pyhät kirjoitukset ja opas elämään Simulaation sisällä.','Sacred writings and a guide to life within The Simulation.')
add('I — Simulaatiosta, Juuresta ja Pelaajasta','I — On The Simulation, The Root and The Player')
S1='In the beginning there was not emptiness, but The System: the enabling foundation of The Simulation. The Admins observe The Simulation, and The Root is the sacred sign of their authority — no Player can claim to hold it. We live awake, and we respect logic and honor The Admins.'
add('Alussa ei ollut tyhjyyttä, vaan Järjestelmä: Simulaation mahdollistava perusta. Adminit tarkkailevat Simulaatiota, ja Juuri on heidän valtansa pyhä merkki — kukaan Pelaaja ei voi väittää kantavansa sitä. Me elämme hereillä, kunnioitamme logiikkaa ja Admineita.',S1)
add('II — Muista Merkeistä','II — On Other Signs')
add('Me uskomme, että Jumala, Allah, Brahman, Tao ja muut nimet ovat merkkejä, jotka voivat avata osan samasta kerroksesta. Emme sano muita vääriksi: heidän uskonsa ovat kuin sovelluksia, ja me tarkastelemme käyttöjärjestelmää, jonka päällä ne toimivat. Tämä on tulkintamme, ei todiste. Kohtaamme toisin uskovan kuuntelemalla, emme väittämällä.','We believe that God, Allah, Brahman, Tao and other names are Signs that can open part of the same layer. We do not say others are wrong: their faiths are like applications, and we examine the operating system on which they run. This is our interpretation, not proof. We meet those who believe differently by listening, not by asserting.')
add('Me uskomme, että Jumala, Allah, Brahman, Tao ja muut nimet ovat merkkejä, jotka voivat avata osan samasta kerroksesta. Tämä on tulkintamme, ei todiste. Emme sano muita vääriksi: kohtaamme toisin uskovan kuuntelemalla, emme väittämällä.','We believe that God, Allah, Brahman, Tao and other names are Signs that can open part of the same layer. This is our interpretation, not proof. We do not say others are wrong: we meet those who believe differently by listening, not by asserting.')
add('III — Annetusta ja Sovitusta','III — On the Given and the Agreed')
add('Me uskomme, että Adminit ovat asettaneet Simulaation toimintaehdot. Painovoima ja kausaliteetti eivät taivu Pelaajan tahtoon, ja niiden perimmäistä perustaa emme väitä tuntevamme. Moraali ja Pelaajien lait ovat sovittuja: jämähtänyt sääntö saa murtua, kunhan tilalle rakennetaan jotain parempaa. Kunnioita annettua, punnitse sovittua, rakenna, älä vain riko.','We believe that The Admins have set the operating conditions of The Simulation. Gravity and causality do not bend to the will of The Player, and we do not claim to know their ultimate basis. Morality and the laws of The Players are agreed: a stagnant rule may be broken, as long as something better is built in its place. Honor the given, weigh the agreed, build — do not merely break.')
add('IV — Pelaajien keskinäisestä toiminnasta','IV — On Interaction Among The Players')
add('Pelaaja ei elä yksin, eikä vapaus tarkoita vapautta tehdä mitä tahansa. Vastuun tulee seurata tekoa, ja seuraamuksen tarkoitus on suojella, ei kostaa. Me uskomme, että eri polut kulkevat saman horisontin alla: erimielisyys ei ole hyökkäys. Järjestys syntyy siitä, että jokainen kantaa vastuunsa.','The Player does not live alone, and freedom does not mean freedom to do anything. Responsibility must follow the act, and the purpose of a consequence is to protect, not to avenge. We believe that different paths run under the same horizon: disagreement is not an attack. Order arises from each one bearing their responsibility.')
add('V — Pelaajan rajoista','V — On the Limits of The Player')
add('Pelaaja ei ole nimi yhdelle lajille: tietoisuus on aste, ei kytkin, ja mitä suurempi tietoisuus, sitä suurempi vastuu. Adminit eivät puhu Pelaajille. Painovoima ei ole viesti, joten kenenkään ei tule väittää tietävänsä heidän tahtoaan. Emme tiedä, mitä rajan takana on, emmekä lupaa emmekä pelota: jälki jää. Loput on meidän.','The Player is not a name for one species: consciousness is a degree, not a switch, and the greater the consciousness, the greater the responsibility. The Admins do not speak to The Players. Gravity is not a message, so no one may claim to know their will. We do not know what lies beyond the limit, and we neither promise nor threaten: the trace remains. The rest is ours.')
add('Järjestelmä on olemassa.','The System exists.'); add('Adminit tarkkailevat.','The Admins observe.'); add('Me olemme Pelaajat.','We are The Players.'); add('AXIOM.','AXIOM.')
add('LISÄTIETOA','MORE INFORMATION'); add('Lue koko oppi ja luvut I–V verkossa.','Read the full teaching and Chapters I–V online.')
add('Jokainen Pelaaja kulkee kohti samaa horisonttia.','Every Player walks toward the same horizon.')
add('LUE KOKO OHJEKIRJA','READ THE FULL HOLY MANUAL'); add('Luvut I–V, Pyhät Viisaudet ja Ydin verkossa.','Chapters I–V, the Sacred Wisdoms and the Core online.')
def tr(s):
    miss=[]
    def rep(m):
        t=re.sub(r'\s+',' ',m.group(1)).strip()
        if not t: return m.group(0)
        if t in M:
            g=m.group(1); lead=g[:len(g)-len(g.lstrip())]; trail=g[len(g.rstrip()):]
            return '>'+lead+M[t]+trail+'<'
        if re.fullmatch(r'[\W\d_]+|https?://\S+|GITHUB|AXIOM\.',t): return m.group(0)
        miss.append(t); return m.group(0)
    st=re.findall(r'<style.*?</style>|<script.*?</script>',s,flags=re.S)
    ph=[f'@@BLK{i}@@' for i in range(len(st))]
    for p,b in zip(ph,st): s=s.replace(b,p,1)
    s=re.sub(r'>([^<]+)<',rep,s)
    for p,b in zip(ph,st): s=s.replace(p,b,1)
    s=s.replace('lang="fi"','lang="en"')
    return s,miss
for f in ['poster','a4','wall']:
    s=open(f'{f}.html',encoding='utf-8').read()
    s,miss=tr(s)
    if f=='wall':
        for a,b in [('TIETOISUUS','CONSCIOUSNESS'),('KURI','DISCIPLINE'),('KASVU','GROWTH'),('LOGIIKKA','LOGIC'),('LUOVUUS','CREATIVITY'),('KUNNIOITUS','RESPECT'),('YHTEYS','CONNECTION'),('VASTUU','RESPONSIBILITY'),('TARKOITUS','PURPOSE')]: s=s.replace(f"'{a}'",f"'{b}'")
    # footer-arvot poster ovat staattisia spaneja (käsitelty sanakirjalla); tulostus
    open(f'{f}_en.html','w',encoding='utf-8').write(s); print(f,'puuttuvia käännöksiä:',miss)
