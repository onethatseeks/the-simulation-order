from playwright.sync_api import sync_playwright
from PIL import Image
jobs=[('poster_en',1190,1683,3508/1190,'A3_en'),('a4_en',1190,1683,2480/1190,'A4_en'),('wall_en',1280,720,2,'WALL_en'),('poster_en_print',1190,1683,3508/1190,'A3_en_print'),('a4_en_print',1190,1683,2480/1190,'A4_en_print')]
with sync_playwright() as p:
    b=p.chromium.launch()
    for n,w,h,s,o in jobs:
        pg=b.new_page(viewport={'width':w,'height':h},device_scale_factor=s); pg.goto(f'file:///home/claude/p/{n}.html'); pg.wait_for_timeout(700)
        info=pg.evaluate("[...document.querySelectorAll('[id]')].map(e=>[e.id,getComputedStyle(e).getPropertyValue('--f'),e.scrollHeight,e.clientHeight])")
        print(n,info); pg.screenshot(path=f'/home/claude/p/{o}_raw.png'); pg.close()
    b.close()
sizes={'A3_en':(3508,4961),'A4_en':(2480,3508),'A3_en_print':(3508,4961),'A4_en_print':(2480,3508),'WALL_en':(2560,1440)}
for o,sz in sizes.items():
    im=Image.open(f'/home/claude/p/{o}_raw.png').convert('RGB')
    if im.size!=sz: im=im.resize(sz,Image.LANCZOS)
    im.save(f'/home/claude/p/{o}.png'); im.resize((1190,int(1190*sz[1]/sz[0]))).save(f'/home/claude/p/{o}_prev.png')
print('valmis')
